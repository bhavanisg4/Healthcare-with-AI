from flask import Flask, render_template, request, redirect, url_for
from ai.health_ai import predict_condition
app=Flask(__name__); users=[]
@app.route('/')
def home(): return redirect(url_for('login'))
@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        users.append({'name':request.form['name'],'email':request.form['email'],'password':request.form['password']}); return redirect(url_for('login'))
    return render_template('register.html')
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        for u in users:
            if u['email']==request.form['email'] and u['password']==request.form['password']: return render_template('dashboard.html',name=u['name'])
        return 'Invalid email or password.'
    return render_template('login.html')
@app.route('/health',methods=['GET','POST'])
def health():
    if request.method=='POST':
        symptoms=request.form.getlist('symptoms')
        if not symptoms: return render_template('health.html',error='Please select at least one symptom.')
        return render_template('health_result.html',symptoms=symptoms,result=predict_condition(symptoms))
    return render_template('health.html')
if __name__=='__main__': app.run(debug=True)
