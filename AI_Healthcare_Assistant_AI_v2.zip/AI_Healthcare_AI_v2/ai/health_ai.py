from sklearn.tree import DecisionTreeClassifier
FEATURES=['fever','cough','headache','sore_throat','runny_nose','body_ache','stomach_pain','vomiting','diarrhea','fatigue']
X=[[1,1,0,1,1,1,0,0,0,1],[1,1,1,1,0,1,0,0,0,1],[1,0,1,0,1,1,0,0,0,1],[0,1,0,1,1,0,0,0,0,1],[0,0,1,0,1,0,0,0,0,0],[0,0,1,0,0,0,0,0,0,1],[1,0,0,0,0,1,1,1,1,1],[0,0,0,0,0,0,1,1,1,0],[0,0,0,0,0,0,1,0,1,0],[1,0,1,0,0,1,0,0,0,1],[0,1,0,1,1,0,0,0,0,0],[0,0,1,0,0,0,0,0,0,0]]
y=['Flu-like illness','Flu-like illness','Common cold','Common cold','Common cold','Headache/migraine-like pattern','Gastrointestinal illness','Gastrointestinal illness','Gastrointestinal illness','Flu-like illness','Common cold','Headache/migraine-like pattern']
model=DecisionTreeClassifier(max_depth=5,random_state=42).fit(X,y)
def predict_condition(selected):
    v=[1 if f in selected else 0 for f in FEATURES]; probs=model.predict_proba([v])[0]; ranked=sorted(zip(model.classes_,probs),key=lambda x:x[1],reverse=True)
    return {'top_condition':ranked[0][0],'score':round(float(ranked[0][1])*100,1),'possibilities':[{'name':n,'score':round(float(p)*100,1)} for n,p in ranked[:3]],'message':'Educational ML prediction only; not a medical diagnosis.'}
